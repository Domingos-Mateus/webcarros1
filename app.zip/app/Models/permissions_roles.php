<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class permissions_roles extends Model
{
    //
}
