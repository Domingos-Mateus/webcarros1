<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class roles_users extends Model
{
    //
}
